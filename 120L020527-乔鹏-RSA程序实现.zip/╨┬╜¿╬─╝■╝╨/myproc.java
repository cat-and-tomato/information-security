public class myproc {
    static int p = 0,q = 0,e,d,s = 31;
    static long f,n;
    static String source = "abcdefghijklmnopqrstuvwxyz";
    public  static long[] res = new long[source.length()];

    public static int randomNum() {
        int temp;
        do{
            temp = (int)(Math.random()*100);
        }while(!isPrimeNumber(temp));
        return temp;
    }

    public static boolean isPrimeNumber(int num){
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if(num % i == 0)
                return false;
        }
        return true;
    }

    public static long[] Encode(String source){
       // int[] res = new int[source.length()];
        long temp;
        for (int i = 0; i < source.length(); i++) {
            temp = (long)((long)source.charAt(i) % n);
            for (int j = 0; j < e - 1; j++) {
                temp = (long)((temp * (long)source.charAt(i)) % n);
            }
            res[i] =temp;
        }
         return res;
    }
    public static long[] Decode(){
        //int[] res = new int[source.length()];
        long temp;
        for (int i = 0; i < res.length; i++) {
            temp = (long)(res[i] % n);
            for (int j = 0; j < d - 1; j++) {
                temp = (long)((temp * res[i]) % n);
            }
            res[i] =temp;
        }
        return res;
    }
    public static void main(String[] args) {
        while((p = randomNum()) < 10);
        while((q = randomNum()) < 10);
        n = p * q;
        f = n - p - q + 1;
        for (e = 2; e < f; e++) {
            int i;
            for (i = e; i > 1; i--) {
                if(f % i == 0)
                    if(e % i == 0)
                        break;
            }
            if (i == 1) break;
        }
        d = (int)((f + 1)/e);
        for (int i = 1; (int)(i * f + 1) % e != 0; i++) {
            d = (int)(((i + 1) * f + 1)/e);
        }
        System.out.println("p = " + p);
        System.out.println("q = " + q);
        System.out.println("f = " + f);
        System.out.println("n = " + n);
        System.out.println("e = " + e);
        System.out.println("d = " + d);
        System.out.println("s = " + s);
        System.out.println("Source:");
        System.out.println(source);
        System.out.println("Encode:");
        Encode(source);
        for (int i = 0; i < source.length(); i++) {
            System.out.printf("%x" + '\t',res[i]);
        }
        System.out.println();
        Decode();
        System.out.println("Decode:");
        for (int i = 0; i < source.length(); i++) {
            System.out.printf("%x" + '\t',res[i]);
        }
        System.out.println();
        System.out.println("Decryption:");
        for (int i = 0; i < source.length(); i++) {
            System.out.printf("%c" + '\t',(char)res[i]);
        }
    }
}
